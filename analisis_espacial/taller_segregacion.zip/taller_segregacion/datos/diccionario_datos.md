# Diccionario de datos

Fuente principal: Secretaría Distrital del Hábitat (SDHT), Subdirección de Información Sectorial (2022). *Análisis del mercado de vivienda en renta en Bogotá*. Documentos técnicos de hábitat.
https://observatorio.habitatbogota.gov.co/wp-content/uploads/2023/02/Analisis_mercado_vivienda_renta_2022.pdf

## arriendo_localidades_2022.csv

Una fila por localidad urbana (19). Sumapaz (rural) no aparece en el informe.

| Variable | Descripción | Fuente en el informe |
|---|---|---|
| `cod_loc` | Código oficial de localidad (01–19), llave para unir con la geometría | IDECA |
| `localidad` | Nombre de la localidad | — |
| `pct_ing_menor_1smmlv` | % de hogares en arriendo o subarriendo con ingresos menores a 1 SMMLV | Ilustración 7 (EM 2021) |
| `pct_ing_1a2_smmlv` | % de hogares en arriendo con ingresos entre 1 y 2 SMMLV | Ilustración 7 (EM 2021) |
| `pct_ing_mayor_2smmlv` | % de hogares en arriendo con ingresos mayores a 2 SMMLV | Ilustración 7 (EM 2021) |
| `pct_hacinamiento` | % de personas que viven en arriendo o subarriendo en hacinamiento mitigable (definición DANE) | Ilustración 14 (EM 2021) |
| `oferta_formal_mensual` | Promedio mensual de inmuebles ofertados en arriendo (apartamentos, apartaestudios y casas; excluye cuartos), mayo 2021 – mayo 2022 | Ilustración 10 (Finca Raíz, base catastral) |

Valores de referencia para Bogotá (total): ingresos <1 SMMLV = 16 %, 1–2 SMMLV = 42 %, >2 SMMLV = 42 %; hacinamiento = 39,0 %.

**Nota de transcripción.** Los tres porcentajes de ingreso se leyeron de las etiquetas de la Ilustración 7 (gráfico de barras apiladas); por localidad suman 99–101 % por redondeo. Conviene cotejarlos con el PDF antes de usarlos en una publicación. Hacinamiento y oferta se leyeron de etiquetas numéricas explícitas (Ilustraciones 14 y 10).

## carga_arriendo_ingreso.csv

Tabla 1 del informe (ECV 2021): mediana del pago de arriendo y del ingreso de los hogares arrendatarios por rango de ingreso.

## localidades_bogota.geojson

Polígonos de las 20 localidades de Bogotá (EPSG:4326, versión simplificada). Origen: capa oficial de localidades de IDECA / Datos Abiertos Bogotá (https://datosabiertos.bogota.gov.co). Campos: `LOCNOMBRE`, `LOCCODIGO`.
